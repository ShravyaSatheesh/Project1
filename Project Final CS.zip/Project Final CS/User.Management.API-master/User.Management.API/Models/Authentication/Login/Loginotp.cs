﻿namespace User.Management.API.Models.Authentication.Login
{
    public class Loginotp
    {
        public string code { get; set; }
        public string  username { get; set; }
    }
}
